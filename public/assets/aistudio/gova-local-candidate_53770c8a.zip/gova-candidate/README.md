# Gova / SynapseEdge experimental platform

Gova is a software simulation and model-integration workbench. Its oscillator, neuron,
power, timing, and stability outputs are simulated or derived values, not measurements
from neuromorphic hardware. It does not establish sentience or improved language reasoning.

## Architecture

- **React / Three.js UI** (`src/App.tsx`, `src/components`): controls, diagnostics,
  visualization, and client-side interaction with the TypeScript engine.
- **TypeScript simulation and control** (`src/lib`): spiking neurons, plasticity,
  homeostasis, sparse-autoencoder experiments, and deterministic watchdog evaluation.
  This layer implements dynamics and control, not just visualization.
- **Express backend** (`server.ts`): model integration, bridge memory, diagnostics,
  user persistence, and authenticated shadow proposal analysis.
- **Python governor** (`synapse_governor.py`, `scripts`): a separate software oscillator
  simulation, response processing, and bridge experiments. It is not a demonstrated
  hardware authority or the sole source of truth for the TypeScript simulation.

The layers exchange data through application routes and bridge scripts; there is no
verified unified authority contract across every experiment. External model identifiers
are configuration choices, not a guarantee of provider availability.

## Local setup and checks

Use Bun **1.4.4** (the committed lockfile uses format version 2), Node 22 when needed
by Node tools, and Python 3.13. Run from the repository root:

```sh
bun install --frozen-lockfile --ignore-scripts
python3 -m venv .venv
.venv/bin/python -m pip install pytest==9.2.0
bun run lint
bun --bun run build
bun run test:security
.venv/bin/python -m pytest -q test_synapse_governor.py
bun run benchmark
```

The build produces `dist/`; the benchmark overwrites `benchmark/results/latest.*`.
The security tests use disposable temporary files. No model calls are required for
these checks. The CI workflow runs these checks, but a workflow file alone is not
proof that a remote run has passed.

For interactive development, configure environment variables from `.env.example`, then
run `bun run dev`. Model features require provider credentials and can incur charges;
Firebase authentication and SQL-backed features require their own service configuration.

## Shadow refactoring contract

`POST /api/watchdog/apply-codebase-refactoring` retains its historical route name for
compatibility, but only analyzes proposals. It requires a Firebase ID token belonging
to `WORKSPACE_OWNER_UID`, plus `targetFile`, full 64-character SHA-256 `expectedPreHash`,
`proposalTitle`, and a nonempty `diff`. A stale hash returns HTTP 409; malformed hashes,
missing files, traversal, and symlinks are rejected. The model-proposal response supplies
the full current file hash. This hash is a freshness check, not a backup or rollback snapshot.

The server evaluates the exact submitted proposal and ignores caller-supplied approvals.
Success means `PROPOSAL_ANALYZED_DRY_RUN`: no source patch, ledger-file write, tuning
change, sandbox execution, or snapshot creation occurred. Nothing is persisted by this
route. The UI likewise does not apply tuning after analysis. No automated patch executor
or structured AST safety verifier is implemented. Text proposals cannot auto-approve;
recognized risks block and other proposals escalate. This intentionally increases human
review burden, including for harmless changes.

## Workspace access and proxies

This version has one shared file-backed workspace. Set `WORKSPACE_OWNER_UID` on the
server to its owner's Firebase UID. Protected bridge reads/writes, diagnostic mutations,
and shadow analysis reject other users; missing owner configuration returns 503. A
request cannot assign ownership. Clients of newly protected routes must send a Firebase
Bearer token; older bridge clients may need updating. Multi-tenant isolation is not claimed.

Rate limiting uses the socket peer by default. `TRUSTED_PROXY_IPS` optionally lists exact
trusted proxy IP addresses (including the actual IPv6 representation when applicable).
Only configure this after verifying the deployment topology and header sanitization.
Forwarded chains are walked from the trusted peer to the first untrusted hop. No blanket
hop-count trust is enabled. Rate limits are process-local, not distributed across replicas.

## Reproducibility and limits

See [governor experiments](scripts/README.md) and [watchdog benchmarks](benchmark/README.md).
Governor comparison: `python scripts/benchmark_multiturn.py --open-loop` versus the same
command without `--open-loop`; both write local reports. These use deterministic simulated
traffic, not model-answer-quality measurements.

Reveal a privately held suite with:

```sh
bun run benchmark -- --reveal path/to/suite.revealed.json
```

Verification requires identical unique ID sets, matching case hashes/metadata, and the
manifest Merkle root. The regression tests cover positive reveals and duplicate, missing,
unknown, tampered, and invalid-root cases. Public suites are regression evidence, not
independent held-out validation; a hash commitment alone does not prove independent authorship.

This candidate addresses a bounded security review. It is not a complete production security
certification. Other model endpoints, simulation dashboards, and historical performance claims
need separate end-to-end review before deployment or autonomous operation.
