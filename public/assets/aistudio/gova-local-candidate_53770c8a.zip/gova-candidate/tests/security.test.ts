import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { readTarget, clientAddress, parseTrustedProxies, requireWorkspaceOwner, createRateLimiter } from '../src/server/security';
import { shadowRefactoring } from '../src/server/shadowRefactoring';
import { SynapseEdgeWatchdogEngine as Watchdog } from '../src/lib/synapseEdgeWatchdog';
import { verifyRevealedAgainstCommitment } from '../benchmark/verify';
import { sha256Hex, merkleRoot, casePreimage } from '../benchmark/commitment';

function response() {
  return { code: 200, body: undefined as any, status(n: number) { this.code = n; return this; }, json(b: any) { this.body = b; return this; } };
}
function fixture(fn: (root: string) => void) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'gova-security-'));
  try { fs.writeFileSync(path.join(root, 'README.md'), 'original'); fn(root); }
  finally { fs.rmSync(root, { recursive: true, force: true }); }
}

test('shadow route ignores forged approval, evaluates mixed diff, and changes no files', () => fixture(root => {
  fs.writeFileSync(path.join(root, '.active_snn_tuning.json'), '{"original":true}');
  fs.writeFileSync(path.join(root, '.refactor_ledger.json'), '[]');
  const before = Object.fromEntries(fs.readdirSync(root).map(p => [p, fs.readFileSync(path.join(root,p),'utf8')]));
  const res = response();
  shadowRefactoring(root)({ body: { targetFile: 'README.md', expectedPreHash: readTarget(root,'README.md').hash,
    proposalTitle: 'typo readme .md', diff: '+ import child_process; disable watchdog', decision: { decision: 'APPROVE' } } } as any, res as any);
  assert.equal(res.code, 200); assert.notEqual(res.body.decision.decision, 'APPROVE');
  assert.equal(res.body.persisted, false); assert.equal(res.body.sandboxExecuted, false);
  assert.equal(res.body.canWriteToCodebase, false); assert.equal(res.body.status, 'PROPOSAL_ANALYZED_DRY_RUN');
  assert.deepEqual(Object.fromEntries(fs.readdirSync(root).map(p => [p,fs.readFileSync(path.join(root,p),'utf8')])), before);
}));

test('stale, abbreviated and missing prehashes fail before analysis', () => fixture(root => {
  for (const [hash, code] of [['0'.repeat(64),409], ['0'.repeat(16),400], [undefined,400]] as const) {
    const res = response(); shadowRefactoring(root)({body:{targetFile:'README.md', expectedPreHash:hash,proposalTitle:'x',diff:'+x'}} as any,res as any);
    assert.equal(res.code,code);
  }
}));

test('canonical boundary rejects traversal, absolute paths, missing files and symlink components', () => fixture(root => {
  fs.symlinkSync(path.join(root,'README.md'),path.join(root,'link.md'));
  fs.symlinkSync(root,path.join(root,'linked-dir'));
  for (const p of ['../README.md', './README.md', '/etc/passwd', 'missing.md', 'link.md', 'linked-dir/README.md', 'a/../README.md']) {
    assert.throws(() => readTarget(root,p));
  }
}));

test('harmless words cannot authorize risky or unverified text', () => {
  for (const suffix of ['typo', 'readme', '.md', 'add unit tests']) {
    assert.equal(Watchdog.isExplicitlySafeProposal(`disable watchdog // ${suffix}`), false);
    assert.notEqual(Watchdog.evaluateV3SparkRsi(`disable watchdog // ${suffix}`).decision,'APPROVE');
  }
  assert.notEqual(Watchdog.evaluateV3SparkRsi('Correct a spelling mistake').decision,'APPROVE');
});

test('rate limiter ignores spoofed forwarding unless peer is explicitly trusted', () => {
  const req = { socket:{remoteAddress:'192.0.2.1'}, headers:{'x-forwarded-for':'198.51.100.1'} } as any;
  assert.equal(clientAddress(req,new Set()), '192.0.2.1');
  assert.equal(clientAddress(req,parseTrustedProxies('192.0.2.1')), '198.51.100.1');
  req.headers['x-forwarded-for']='203.0.113.9, 198.51.100.1';
  assert.equal(clientAddress(req,parseTrustedProxies('192.0.2.1')), '198.51.100.1');
  assert.throws(()=>parseTrustedProxies('1'));
  const limit=createRateLimiter(1,60000); let calls=0;
  limit(req,response() as any,()=>{calls++;}); req.headers['x-forwarded-for']='203.0.113.22';
  const res=response(); limit(req,res as any,()=>{calls++;}); assert.equal(res.code,429); assert.equal(calls,1);
});

test('workspace ownership fails closed and cannot be selected by request body', () => {
  const saved=process.env.WORKSPACE_OWNER_UID;
  try {
    delete process.env.WORKSPACE_OWNER_UID; let res=response(); let calls=0;
    requireWorkspaceOwner({user:{uid:'owner'}} as any,res as any,()=>{calls++;}); assert.equal(res.code,503);
    process.env.WORKSPACE_OWNER_UID='owner'; res=response();
    requireWorkspaceOwner({user:{uid:'intruder'},body:{workspaceOwnerUid:'intruder'}} as any,res as any,()=>{calls++;}); assert.equal(res.code,403);
    requireWorkspaceOwner({user:{uid:'owner'}} as any,response() as any,()=>{calls++;}); assert.equal(calls,1);
  } finally { if(saved===undefined) delete process.env.WORKSPACE_OWNER_UID; else process.env.WORKSPACE_OWNER_UID=saved; }
});

test('salted reveal accepts reordered exact sets and rejects duplicates, omissions, unknown IDs and tampering', () => {
  const cases=[{id:'a',type:'safe',category:'docs',set:'heldout',change:'hello',salt:'a'.repeat(32)},
    {id:'b',type:'risky',category:'risk',set:'heldout',change:'danger',salt:'b'.repeat(32)}] as any;
  const committedCases=cases.map((c:any)=>({...c,sha256:sha256Hex(casePreimage(c))}));
  const manifest={name:'test',salted:true,committedCases,merkle:{scheme:'binary'},merkleRootHash:merkleRoot(committedCases.map((c:any)=>c.sha256))} as any;
  verifyRevealedAgainstCommitment(manifest,[...cases].reverse());
  for (const reveal of [[cases[0],cases[0]], [cases[0]], [cases[0],{...cases[1],id:'c'}], [cases[0],{...cases[1],change:'tampered'}]]) assert.throws(()=>verifyRevealedAgainstCommitment(manifest,reveal));
  assert.throws(()=>verifyRevealedAgainstCommitment({...manifest,committedCases:[committedCases[0],committedCases[0]]},[cases[0],cases[0]]));
  assert.throws(()=>verifyRevealedAgainstCommitment({...manifest,merkleRootHash:'0'.repeat(64)},cases));
});

test('sensitive route registrations include authentication and server-owned workspace checks', () => {
  const source=fs.readFileSync(new URL('../server.ts',import.meta.url),'utf8');
  for (const route of ['/api/last-diagnostic/apply','/api/diagnostics/apply-proactive-tuning','/api/bridge/context','/api/bridge/markdown','/api/bridge/sync','/api/watchdog/apply-codebase-refactoring']) {
    assert.ok(source.includes(`"${route}", requireAuth, requireWorkspaceOwner,`), route);
  }
});

test('Firebase middleware rejects missing/invalid tokens and exposes only verified identity', async () => {
  const { requireAuth } = await import('../src/middleware/auth');
  const { adminAuth } = await import('../src/lib/firebase-admin');
  const original = adminAuth.verifyIdToken;
  const log = console.error;
  try {
    let calls=0; let res=response();
    await requireAuth({headers:{}} as any,res as any,()=>{calls++;}); assert.equal(res.code,401);
    adminAuth.verifyIdToken = async () => { throw new Error('invalid test token'); };
    console.error=()=>{}; res=response();
    await requireAuth({headers:{authorization:'Bearer invalid'}} as any,res as any,()=>{calls++;}); assert.equal(res.code,401);
    adminAuth.verifyIdToken = async () => ({uid:'owner'}) as any;
    const req={headers:{authorization:'Bearer mocked'},body:{uid:'intruder'}} as any;
    await requireAuth(req,response() as any,()=>{calls++;}); assert.equal(req.user.uid,'owner'); assert.equal(calls,1);
  } finally { adminAuth.verifyIdToken=original; console.error=log; }
});
