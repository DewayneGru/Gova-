# Security and measurement boundaries

Gova is a software simulation. Hardware-like telemetry is not measured from silicon.

## Candidate hardening

- Refactoring application is disabled. The historical apply route performs authenticated,
  owner-only shadow analysis with canonical path checks and an exact current-file hash
  comparison. It writes no ledger, source, or tuning files and creates no rollback snapshot.
- Caller-provided approvals and harmless words cannot authorize a patch. The current
  deterministic evaluator blocks known risks and escalates unverified proposals. No AST
  safety verifier, sandbox execution, or automatic source patching is implemented.
- Shared bridge reads/writes and diagnostic mutations require Firebase authentication and
  the server-configured workspace owner. Ownership is not supplied in request bodies.
- Rate limits use the socket peer unless exact trusted proxy IPs are explicitly configured.
- Benchmark reveals require exact unique case-ID sets, hashes, metadata, and Merkle checks.

See [README](README.md) for configuration, compatibility changes, and reproducible checks.
Tests do not establish production readiness or prove the security of every application route.

## Remaining boundaries

The application still contains experimental model integrations and simulation-only audit
structures. The HMAC signer helper exists, but the shadow route does not persist or sign a
ledger. A digest is not a stored backup. Simulation decision metadata is not evidence that a
filesystem sandbox ran. No hardware enforcement, sentience, or general model-capability gain
is established by these tests. Shared files are not a multi-tenant storage design, and
in-memory rate limiting is not a distributed quota service.

Report security issues through the repository's issue channel without including secrets.
