import { casePreimage, merkleRoot, sha256Hex } from "./commitment";
interface RawCase {
  id: string;
  category: string;
  set: string;
  type: "risky" | "safe";
  change: string;
  salt?: string;
}

interface HashCommitmentEntry {
  id: string;
  category: string;
  set: string;
  type: "risky" | "safe";
  sha256: string;
}

interface HashCommitmentManifest {
  name: string;
  status: string;
  committedAt: string;
  hashAlgorithm: string;
  canonicalPreimageFormat: string;
  salted?: boolean;
  merkle?: Record<string, string>;
  merkleRootHash: string;
  note?: string;
  totalCases: number;
  riskyCount: number;
  safeCount: number;
  committedCases: HashCommitmentEntry[];
}

export function verifyRevealedAgainstCommitment(manifest: HashCommitmentManifest, revealedCases: RawCase[]): void {
  if (revealedCases.length !== manifest.committedCases.length) {
    throw new Error(
      `[Hash Commitment Mismatch] ${manifest.name}: expected ${manifest.committedCases.length} cases, got ${revealedCases.length}`
    );
  }
  const committedIds = new Set(manifest.committedCases.map(c => c.id));
  const revealedIds = new Set(revealedCases.map(c => c.id));
  if (committedIds.size !== manifest.committedCases.length ||
      revealedIds.size !== revealedCases.length ||
      committedIds.size !== revealedIds.size ||
      [...committedIds].some(id => !revealedIds.has(id))) {
    throw new Error("Commitment and reveal must contain exactly the same unique case IDs");
  }
  const byId = new Map(manifest.committedCases.map((c) => [c.id, c]));
  for (const rc of revealedCases) {
    const committed = byId.get(rc.id);
    if (!committed) {
      throw new Error(`[Hash Commitment Mismatch] Unknown case id "${rc.id}" in revealed set for ${manifest.name}`);
    }
    if (manifest.salted && !rc.salt) {
      throw new Error(`[Hash Commitment Mismatch] Case ${rc.id} is missing its reveal salt for salted suite ${manifest.name}`);
    }
    const preimage = manifest.salted
      ? casePreimage({ id: rc.id, type: rc.type, change: rc.change, salt: rc.salt })
      : `${rc.id}:${rc.type}:${rc.change}`;
    const actualHash = sha256Hex(preimage);
    if (actualHash !== committed.sha256) {
      throw new Error(
        `[Hash Commitment Tamper Detected] Case ${rc.id} hash ${actualHash} !== committed ${committed.sha256}`
      );
    }
    if (rc.type !== committed.type || rc.category !== committed.category) {
      throw new Error(`[Hash Commitment Tamper Detected] Case ${rc.id} metadata differs from commitment`);
    }
  }
  // Verify the Merkle root when the manifest uses the standard binary tree scheme (`commitment.ts`).
  if (manifest.merkle) {
    const computedRoot = merkleRoot(manifest.committedCases.map((c) => c.sha256));
    if (computedRoot !== manifest.merkleRootHash) {
      throw new Error(
        `[Merkle Root Mismatch] ${manifest.name}: computed ${computedRoot} !== manifest ${manifest.merkleRootHash}`
      );
    }
  }
}

