import { auth } from './firebase';

/** Authenticated access to the single server-owned workspace. */
export async function workspaceFetch(url: string, init: RequestInit = {}): Promise<Response> {
  const user = auth.currentUser;
  if (!user) throw new Error('Sign in as the workspace owner');
  const headers = new Headers(init.headers);
  headers.set('Authorization', `Bearer ${await user.getIdToken()}`);
  const response = await fetch(url, { ...init, headers });
  if (!response.ok) {
    const error = await response.clone().json().catch(() => ({}));
    throw new Error(error.error || `Workspace request failed (${response.status})`);
  }
  return response;
}
