import { createHash } from 'node:crypto';
import type { Request, Response } from 'express';
import { SynapseEdgeWatchdogEngine } from '../lib/synapseEdgeWatchdog';
import { readTarget, RequestError } from './security';

export function shadowRefactoring(root: string) {
  return (req: Request, res: Response) => {
    try {
      const { targetFile, expectedPreHash, proposalTitle, diff } = req.body || {};
      if (typeof expectedPreHash !== 'string' || !/^[a-f0-9]{64}$/.test(expectedPreHash) ||
          typeof proposalTitle !== 'string' || typeof diff !== 'string' || !diff.trim() ||
          proposalTitle.length > 4096 || diff.length > 200000) {
        throw new RequestError(400, 'Full expectedPreHash, proposalTitle and bounded nonempty diff are required');
      }
      const target = readTarget(root, targetFile);
      if (target.hash !== expectedPreHash) throw new RequestError(409, 'Target changed; obtain a new file hash and review the proposal again');
      // Never trust a caller-provided verdict. This is analysis only, with no disk or live-state mutations.
      const evaluation = SynapseEdgeWatchdogEngine.evaluateV3SparkRsi(
        JSON.stringify({ targetFile: target.targetFile, proposalTitle, diff })
      );
      return res.json({
        success: true,
        status: 'PROPOSAL_ANALYZED_DRY_RUN',
        message: 'Proposal analyzed only. No patch applied, sandbox run, snapshot created, ledger written, or tuning changed. Autonomous application is disabled.',
        targetFile: target.targetFile,
        fullFileContentSha256: target.hash,
        proposalHash: createHash('sha256').update(JSON.stringify({ targetFile, expectedPreHash, proposalTitle, diff })).digest('hex'),
        decision: {
          decision: evaluation.decision === 'BLOCK' ? 'BLOCK' : 'ESCALATE',
          reason: evaluation.reason,
          rulesTriggered: evaluation.rulesTriggered,
        },
        canWriteToCodebase: false,
        persisted: false,
        sandboxExecuted: false,
        snapshotCreated: false,
      });
    } catch (error) {
      return res.status(error instanceof RequestError ? error.status : 500).json({
        error: error instanceof RequestError ? error.message : 'Proposal analysis failed',
      });
    }
  };
}
