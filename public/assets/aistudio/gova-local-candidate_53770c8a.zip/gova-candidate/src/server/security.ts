import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { isIP } from 'node:net';
import type { Request, Response, NextFunction } from 'express';

export class RequestError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

export function readTarget(root: string, target: unknown) {
  if (typeof target !== 'string' || !target || path.isAbsolute(target) ||
      target.includes('\\') || target.includes('\0') || target.split('/').some(p => !p || p === '..' || p === '.')) {
    throw new RequestError(400, 'A canonical repository-relative file path is required');
  }
  const base = fs.realpathSync(root);
  const resolved = path.resolve(base, target);
  if (!resolved.startsWith(base + path.sep)) throw new RequestError(400, 'Target is outside repository');
  try {
    let current = base;
    for (const part of target.split('/')) {
      current = path.join(current, part);
      if (fs.lstatSync(current).isSymbolicLink()) throw new RequestError(400, 'Symlinks are not permitted');
    }
    if (fs.realpathSync(resolved) !== resolved || !fs.statSync(resolved).isFile()) {
      throw new RequestError(400, 'Target must be a regular repository file');
    }
    const fd = fs.openSync(resolved, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
    try {
      return { targetFile: target, hash: crypto.createHash('sha256').update(fs.readFileSync(fd)).digest('hex') };
    } finally { fs.closeSync(fd); }
  } catch (error) {
    if (error instanceof RequestError) throw error;
    throw new RequestError(400, 'Target file is missing or unreadable');
  }
}

// Exact IP addresses only: no hop-count assumptions or blanket forwarded-header trust.
export function parseTrustedProxies(value = ''): Set<string> {
  const entries = value.split(',').map(s => s.trim()).filter(Boolean);
  if (entries.some(ip => !isIP(ip))) throw new Error('TRUSTED_PROXY_IPS must contain exact IP addresses');
  return new Set(entries);
}
export function clientAddress(req: Pick<Request, 'socket' | 'headers'>, trusted: Set<string>): string {
  const peer = req.socket.remoteAddress || 'unknown';
  if (!trusted.has(peer)) return peer;
  const header = req.headers['x-forwarded-for'];
  if (typeof header !== 'string') return peer;
  const chain = header.split(',').map(s => s.trim());
  if (!chain.length || chain.some(ip => !isIP(ip))) return peer;
  // Walk from the authenticated network peer toward the client; stop at first untrusted hop.
  let address = peer;
  for (let i = chain.length - 1; i >= 0 && trusted.has(address); i--) address = chain[i];
  return address;
}
export function createRateLimiter(maxRequests: number, windowMs: number, trusted = new Set<string>()) {
  const buckets = new Map<string, number[]>();
  return (req: Request, res: Response, next: NextFunction) => {
    const now = Date.now();
    for (const [ip, times] of buckets) if (times[times.length - 1] <= now - windowMs) buckets.delete(ip);
    const ip = clientAddress(req, trusted);
    const times = (buckets.get(ip) || []).filter(t => t > now - windowMs);
    if (times.length >= maxRequests) return res.status(429).json({ error: 'Rate limit exceeded' });
    times.push(now); buckets.set(ip, times); next();
  };
}

// This app has one file-backed workspace. Ownership is server configuration,
// never a client-supplied workspace ID or a mutable bridge-memory field.
export function requireWorkspaceOwner(req: Request & { user?: { uid: string } }, res: Response, next: NextFunction) {
  const owner = process.env.WORKSPACE_OWNER_UID;
  if (!owner) return res.status(503).json({ error: 'Workspace owner is not configured' });
  if (!req.user || req.user.uid !== owner) return res.status(403).json({ error: 'Workspace owner access required' });
  next();
}
